package Arraylist;

import java.util.ArrayList;

public class Impares {
	public void impar() {
		int i;
		int n = 1000;
		ArrayList<Integer> vetor = new ArrayList<>();
		for (i=0; i<=n;i++) {
			if ((i % 2 == 1))
				vetor.add(i);
		}
		System.out.println(vetor);
		System.out.println(vetor.get(10));
		System.out.println(vetor.contains(3));
	}
}
