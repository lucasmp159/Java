package Arraylist;

public class Principal {

	public static void main(String[] args) {
		Impares obj = new Impares();
		obj.impar();
		Cliente obj1 = new Cliente(); 
		obj1.cliente();
	}
}
